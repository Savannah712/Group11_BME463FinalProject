#include "BME463_lib.h"

void shift_right(float *in, int const n) {
    for (int i = n - 1; i > 0; i--) {
        in[i] = in[i-1]; 
    }
}

float filter_IIR(float const a, float const* inx, float const* cx, int
const nx, float const* iny, float const* cy, int const ny) {
    float sumX = 0, sumY = 0; 

    for (int k = 0; k < nx; k++) {
        sumX += inx[k] * cx[k]; 
    }

    for (int g = 1; g < ny; g++) {
        sumY += iny[g] * cy[g]; 
    }

    return sumY + (a * sumX); 
}


float filter_FIR(float const a, float const* in, float const* c, int const n) {
    float sumX = 0; 

    for (int k = 0; k < n; k++) {
        sumX += in[k] * c[k]; 
    }

    return a * sumX; 
}